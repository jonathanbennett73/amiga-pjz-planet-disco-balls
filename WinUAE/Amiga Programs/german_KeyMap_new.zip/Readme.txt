WinUAE_D Keymap

Die WinUAE_D Keymap ist eine Alternative zu der uae_german Keymap. uae_german
ben�tigt einen Hack (der bei deutschen Tastaturen automatisch aktiviert wird) 
in WinUAE um richtig zu funktionieren, dieser Hack ist umst�ndlich und im 
Allgemeinen nicht notwendig - das WinUAE_D Keymap arbeitet ohne diesen Hack, 
jedoch MUSS der Hack bei Benutzung von WinUAE_D deaktiviert werden.
Sehr wahrscheinlich funktioniert die Keymap in allen UAE Version, die den Hack
nicht haben oder bzw deaktivieren lassen.


Vorraussetzungen:
WinUAE 0.90+ (es ist umst�ndlich bei �ltere Versionen den Hack zu deaktivieren)
Deutsche Standard 101/102 Tasten PC-Tastatur.


Einstellungen in WinUAE:

Um den Hack in WinUAE zu deaktivieren mu� die Eingabekonfiguration auf etwas
Anderes als Kompatibilit�tsmodus gesetzt werden. 
Weiters sollte die <#>-Taste der PC-Tastatur auf 0x2B gesetzt werden, dies ist
nicht unbedingt notwendig aber bildet den realen deutschen Amiga besser nach.


Einstellungen in der Workbench:

Die WinUAE Datei mu� zuerst auf den emulierten Amiga �bertragen und dort nach 
DEVS:Keymaps kopiert werden. Danach mu� die Keymap auch ausgew�hlt werden. Das
notwendige Programm f�r diese Einstellung hei�t "Input" und ist im Prefs 
Verzeichnis


TastaturLayout:

Ist die Keymap erst einmal installiert, funktioniert die PC-Tastatur wie 
gewohnt unter Windows, einige Besonderheiten gibt es jedoch:

EuroSymbol:
		Das Eurosymbol *sollte* funktionieren, zur korrekten Anzeige ist
		jedoch ein Zeichensatz (Font) notwendig, der dieses Symbol enth�lt.
		
<#> Taste:
		Unter AmigaDOS hat das ` Zeichen eine besondere Bedeutung 
		(zB echo `date` ), ist aber �ber eine PC-Tastatur nicht so leicht 
		zug�nglich. Alt+<#> erzeugt dieses ` Zeichen